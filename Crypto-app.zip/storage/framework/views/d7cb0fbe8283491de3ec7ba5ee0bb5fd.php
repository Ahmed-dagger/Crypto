<?php echo e($slot); ?>

<?php /**PATH D:\Crypto\Crypto-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>