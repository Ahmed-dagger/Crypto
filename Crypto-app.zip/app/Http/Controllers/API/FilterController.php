<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Services\CoinGeckoService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class FilterController extends Controller
{
    protected $coinGeckoService;
    public function __construct(CoinGeckoService $coinGeckoService)
    {
        $this->coinGeckoService = $coinGeckoService;
    }


    public function getHighestChangeUp()
    {
        return response()->json($this->coinGeckoService->getHighestChangeUp());
    }


    public function getHighestChangeDown()
    {
        return response()->json($this->coinGeckoService->getHighestChangeDown());
    }


    public function getHighestVolume()
    {
        return response()->json($this->coinGeckoService->getHighestVolume());
    }


    public function getNewCoins()
    {
        return response()->json($this->coinGeckoService->getNewCoins());
    }


    public function getPopularCoins()
    {
        return response()->json($this->coinGeckoService->getPopularCoins());
    }
}
