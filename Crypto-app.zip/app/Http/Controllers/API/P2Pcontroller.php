<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\P2P;
use Illuminate\Support\Facades\Auth;

class P2PController extends Controller
{
    public function createBuyAd(Request $request)
    {
        $validated = $request->validate([
            'currency' => 'required|string|max:10',
            'amount' => 'required|numeric|min:0.0001',
            'fiat_amount' => 'required|numeric|min:0.01',
            'fiat_currency' => 'required|string|max:10',
            'payment_method' => 'required|string|max:255',
        ]);

        $p2p = P2P::create([
            'user_id' => Auth::id(),
            'trade_type' => 'buy',
            'currency' => $validated['currency'],
            'amount' => $validated['amount'],
            'fiat_amount' => $validated['fiat_amount'],
            'fiat_currency' => $validated['fiat_currency'],
            'payment_method' => $validated['payment_method'],
            'transfer_status' => 'pending',
        ]);

        return response()->json([
            'message' => 'Buy P2P ad created successfully.',
            'data' => $p2p,
        ], 200);
    }

    public function getBuyAds()
    {
        $buyAds = P2P::with('user:id,name') // eager load user name
            ->where('trade_type', 'buy')
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json([
            'message' => 'Buy ads retrieved successfully.',
            'data' => $buyAds,
        ], 200);
    }

    public function createSellAd(Request $request)
    {
        $validated = $request->validate([
            'currency' => 'required|string|max:10',
            'amount' => 'required|numeric|min:0.0001',
            'fiat_amount' => 'required|numeric|min:0.01',
            'fiat_currency' => 'required|string|max:10',
            'payment_method' => 'required|string|max:255',
        ]);

        $p2p = P2P::create([
            'user_id' => Auth::id(),
            'trade_type' => 'sell',
            'currency' => $validated['currency'],
            'amount' => $validated['amount'],
            'fiat_amount' => $validated['fiat_amount'],
            'fiat_currency' => $validated['fiat_currency'],
            'payment_method' => $validated['payment_method'],
            'transfer_status' => 'pending',
        ]);

        return response()->json([
            'message' => 'Buy P2P ad created successfully.',
            'data' => $p2p,
        ], 200);
    }

    public function getSellAds()
    {
        $sellAds = P2P::with('user:id,name') // Load user name
            ->where('trade_type', 'sell')
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json([
            'message' => 'Sell ads retrieved successfully.',
            'data' => $sellAds,
        ], 200);
    }

    public function acceptAd(Request $request, $id)
    {
        $p2p = P2P::find($id);

        if (!$p2p) {
            return response()->json(['message' => 'Ad not found.'], 404);
        }

        // Prevent ad creator from accepting their own ad
        if ($p2p->user_id === Auth::id()) {
            return response()->json(['message' => 'You cannot accept your own ad.'], 403);
        }

        // Check if ad already has a counterparty
        if ($p2p->counterparty_id) {
            return response()->json(['message' => 'This ad has already been accepted.'], 400);
        }

        $p2p->counterparty_id = Auth::id();
        $p2p->transfer_status = 'in_progress';
        $p2p->save();

        return response()->json([
            'message' => 'You have successfully accepted this trade.',
            'data' => $p2p,
        ], 200);
    }


    public function completeTrade($id)
    {
        $p2p = P2P::find($id);

        if (!$p2p) {
            return response()->json(['message' => 'Trade not found.'], 404);
        }

        // Only the seller (user who created a "sell" ad) can complete the trade
        if ($p2p->trade_type === 'sell' && $p2p->user_id !== Auth::id()) {
            return response()->json(['message' => 'Only the seller can finalize this trade.'], 403);
        }

        // Trade must already be accepted
        if (!$p2p->counterparty_id) {
            return response()->json(['message' => 'This trade has not been accepted yet.'], 400);
        }

        // Trade must be in progress
        if ($p2p->transfer_status !== 'in_progress') {
            return response()->json(['message' => 'This trade is not in progress.'], 400);
        }

        // Mark as success
        $p2p->transfer_status = 'completed';
        $p2p->save();

        return response()->json([
            'message' => 'Trade has been successfully completed.',
            'data' => $p2p,
        ]);
    }

    
public function cancelTrade($id)
{
    $p2p = P2P::find($id);

    if (!$p2p) {
        return response()->json(['message' => 'Trade not found.'], 404);
    }

    // Only ad creator or counterparty can cancel
    if (Auth::id() !== $p2p->user_id && Auth::id() !== $p2p->counterparty_id) {
        return response()->json(['message' => 'Unauthorized to cancel this trade.'], 403);
    }

    // Trade should not already be completed or cancelled
    if (in_array($p2p->transfer_status, ['success', 'cancelled'])) {
        return response()->json(['message' => 'Trade cannot be cancelled.'], 400);
    }

    // Update status
    $p2p->transfer_status = 'cancelled';
    $p2p->save();

    return response()->json([
        'message' => 'Trade has been cancelled successfully.',
        'data' => $p2p,
    ]);
}
}
